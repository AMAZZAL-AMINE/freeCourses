

<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="text-muted border-bottom mb-3">Add New Cours</h1>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-primary alert-dismissible fade show" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <strong> <?php echo e(session('message')); ?></strong> 
        </div>
        
        <script>
          $(".alert").alert();
        </script>
    <?php endif; ?>
    <form action="<?php echo e(route('cours.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input id="cours" class="form-control" type="text" name="title" placeholder="Cours Title" value="<?php echo e($cours->title); ?>">
        </div>
        <div class="form-group">
            <input id="slug" class="form-control" type="text" name="slug" placeholder="Cours Slug" value="<?php echo e($cours->slug); ?>">
        </div>

        <div class="form-group">
            <textarea id="desc" name="desc" placeholder="Cours Description"> <?php echo e($cours->desc); ?> </textarea>
        </div>
        <div class="form-group">
            <input id="created_by" class="form-control" type="text" name="created_by" placeholder="Who Creted this Cours ?" value="<?php echo e($cours->created_by); ?>">
        </div>
        <div class="form-group">
            <input id="url" class="form-control" type="url" name="url" placeholder="Link From Google Drive" value="<?php echo e($cours->url); ?>">
        </div>
        <div class="form-group">
            <div>
              <img src="<?php echo e(asset('/storage/'.$cours->img )); ?>" alt="" class="w-50">
            </div>
            <input id="img" class="form-control-file bt-white p-2 rounded border" type="file" name="img" placeholder="Cours Image">
        </div>
        <div class="form-group">
            <select id="category" class="form-control" name="category">
                <option value="<?php echo e($cours->category_id); ?>"><?php echo e($cours->categories->name); ?></option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>
        <button class="btn btn-primary w-100" type="submit">Add Cours</button>
    </form>
</div>


<script>
    tinymce.init({
        selector: 'textarea',
        plugins: 'a11ychecker advcode casechange export formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
        toolbar: 'a11ycheck addcomment showcomments casechange checklist code export formatpainter pageembed permanentpen table',
        toolbar_mode: 'floating',
        tinycomments_mode: 'embedded',
        tinycomments_author: 'Author name',
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lv-projects\freecours\freeCours\resources\views/admin/updatecours.blade.php ENDPATH**/ ?>