

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="courses_some_quots">
            <div class="text__quots">
                <div><h1>We Help You,</h1></div>
                <div>
                    <p>
                    We Car About You, Its Time To Build Your Skills And Start Your Business, We Build This For Your, Get All Premium
                    Couses For Free,  
                    </p>
                </div>
                <div>
                   <a href="https://paypal.me/amineamazzal866?country.x=MA&locale.x=en_US"> <button class="btn"><img style="width: 10%;" src="/img/pay.png" alt="">  Suport Us With A Donation  </button> </a>
                </div>
            </div>
        </div>

        <div class="all_courses_showing ">
            <div class="group_for_all">

            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cart_cours">
                    <a href="<?php echo e(route('cours.details',$cours->slug)); ?>">
                        <div class="card_img"> <img src="<?php echo e(asset('/storage/'.$cours->img)); ?>" alt="">  </div>
                        <div class="card_cours_body">
                            <div class="title_cours"><b> <?php echo e(Str::limit($cours->title, 50, '...')); ?> </b></div>
                            <div class="desc_cours"><?php echo e(Str::limit(htmlspecialchars(trim(strip_tags($cours->desc))), 30, '...')); ?></div>
                            <div> <a href="<?php echo e(route('cours.details',$cours->slug)); ?>"><button>Show Details</button></a> </div>
                        </div>  
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($courses->count() == 0): ?>
                    <div class="text-center mt-5 mb-5">
                        <p style="font-size : 20px;">Sorry! There No Courses Right Now</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="d-flex justify-content-center pt-5">
         <?php echo e($courses->links("pagination::bootstrap-4")); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lv-projects\freecours\freeCours\resources\views/cours/index.blade.php ENDPATH**/ ?>