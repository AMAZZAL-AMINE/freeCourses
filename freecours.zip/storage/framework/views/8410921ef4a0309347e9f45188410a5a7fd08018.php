

<?php $__env->startSection('content'); ?>

    <div class="container">
            <div class="all_categories_title">
                 <h1 class="text text-center border-bottom">Select Categories</h1>
            </div>
        <div class="all_categories_click_event">

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cart_category">
                    <div>
                        <img src="<?php echo e(asset('/storage/'.$category->img)); ?>" alt="<?php echo e($category->name); ?>">  
                    </div>
                    <div class="text">
                        <b> <?php echo e($category->name); ?> </b>
                    </div>
                    <div>
                        <a href="<?php echo e(route('category.find',$category->slug)); ?>"><button class="btn btn-primary w-100"> Go To Courses </button></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
            <?php if($categories->count() == 0): ?>
                <div class="text-center mt-5 mb-5">
                    <p style="font-size : 20px;"> Sorry! There's No Categories To Show ): </p>
                </div>
            <?php endif; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lv-projects\freecours\freeCours\resources\views/cours/allcategories.blade.php ENDPATH**/ ?>