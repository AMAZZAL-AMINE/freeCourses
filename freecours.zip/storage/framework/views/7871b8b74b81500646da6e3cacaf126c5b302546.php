

<?php $__env->startSection('content'); ?>

    <div class="detail_page">
        <div class="top_cours_details" >
            <div class="courst_etals_text">
                <div class="title_cours_details">
                    <h2> <?php echo e($cours->title); ?> </h2>
                </div>
                <div class="createdby_cours_details">
                    <b>By : <?php echo e($cours->created_by); ?> </b>
                </div>
                <div class="description_page_details">
                     <blockquote cite="description" class="text-muted">
                             <?php echo $cours->desc ?>
                     </blockquote>
                </div>
                <div class="link_dowload_cours mt-3">
                    <a href="<?php echo e($cours->url); ?>"> <button class="btn btn-danger w-100" type=""><i class="fa fa-download" aria-hidden="true"></i> Dwload Cours</button> </a>
                </div>
            </div>
            <div class="cours_detais_img">
                <img src="<?php echo e(asset('/storage/'.$cours->img)); ?>" alt="">
            </div>
        </div>



    </div>

    <div class="all_courses_showing ">
        <h2 class="text-center mb-5">Related Courses</h2>
            <div class="group_for_all">

            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cart_cours">
                    <a href="<?php echo e(route('cours.details',$cours->slug)); ?>">
                        <div class="card_img"> <img src="<?php echo e(asset('/storage/'.$cours->img)); ?>" alt="">  </div>
                        <div class="card_cours_body">
                            <div class="title_cours"><b> <?php echo e(Str::limit($cours->title, 50, '')); ?> </b></div>
                            <div class="desc_cours"><?php echo e(Str::limit(htmlspecialchars(trim(strip_tags($cours->desc))), 30, '...')); ?></div>
                            <div> <a href="<?php echo e(route('cours.details',$cours->slug)); ?>"><button>Show Details</button></a> </div>
                        </div>  
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($courses->count() == 0): ?>
                    <div class="text-center mt-5 mb-5">
                        <p style="font-size : 20px;">Sorry! There No Courses Right Now</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lv-projects\freecours\freeCours\resources\views/cours/coursdetails.blade.php ENDPATH**/ ?>