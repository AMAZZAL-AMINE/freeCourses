

<?php $__env->startSection('content'); ?>


<div class="">
    <?php if($courses->isNotempty()): ?>
        <?php if(!empty($search)): ?>
    <div class="title__header__al_products">
        <div>
                <span></span>
            </div>
            <div class="____text">
                <h2 class="text-center">  Courses Search Result  </h2>
            </div>
        </div>
        <div class="all_courses_showing ">
            <div class="group_for_all">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cart_cours">
                        <a href="<?php echo e(route('cours.details',$cours->slug)); ?>">
                            <div class="card_img"> <img src="<?php echo e(asset('/storage/'.$cours->img)); ?>" alt="">  </div>
                            <div class="card_cours_body">
                                <div class="title_cours"><b> <?php echo e(Str::limit($cours->title, 50, '...')); ?> </b></div>
                                <div class="desc_cours"><?php echo e(Str::limit(htmlspecialchars(trim(strip_tags($cours->desc))), 30, '...')); ?></div>
                                <div> <a href="<?php echo e(route('cours.details',$cours->slug)); ?>"><button>Show Details</button></a> </div>
                            </div>  
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($courses->count() == 0): ?>
                    <div class="text-center mt-5 mb-5">
                        <p style="font-size : 20px;">Sorry! There No Courses Right Now</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?> 
                <div class="text-center mt-5">
                    <img style="width: 10%;" src="/img/emty.png" alt="">
                     <h2 class="font-weight-bold text-danger">You Put Empty Value</h2>
                </div>
        <?php endif; ?>
            <?php else: ?> 
               <div class="text-center mt-5">
                    <img style="width: 10%; margin-bottom: 35px;" src="/img/not.png" alt="">
                     <h3 class="font-weight-bold text-danger">No Cours Found with  this value <span class="text-primary"> "<?php echo e($search); ?>" </span></h3>
                </div>
         <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lv-projects\freecours\freeCours\resources\views/cours/search.blade.php ENDPATH**/ ?>