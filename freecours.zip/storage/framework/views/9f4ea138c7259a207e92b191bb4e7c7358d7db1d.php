

<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1>Hello World</h1>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lv-projects\freecours\freeCours\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>